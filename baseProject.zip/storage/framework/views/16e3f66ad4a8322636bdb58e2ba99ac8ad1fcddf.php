<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="title">
            Permissions de <?php echo e($role->name); ?>

        </h1>

        <table class="table table-hover">
            <?php echo $__env->make('layouts.showResponse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(route('roles.add_permissions', $role->id)); ?>" class="btn btn-primary">Adicionar permission</a>
            <tr>
                <th>Name</th>
                <th>Label</th>
                <th width="150px">Ações</th>
            </tr>

            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($permission->name); ?></td>
                    <td><?php echo e($permission->label); ?></td>
                    <td>
                        <form action="<?php echo e(route('roles.remove_permission')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="roleId" value="<?php echo e($role->id); ?>">
                            <input type="hidden" name="permissionId" value="<?php echo e($permission->id); ?>">
                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="90">
                        <p>Nenhum Resultado!</p>
                    </td>
                </tr>
            <?php endif; ?>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/admin/roles/permissions.blade.php ENDPATH**/ ?>