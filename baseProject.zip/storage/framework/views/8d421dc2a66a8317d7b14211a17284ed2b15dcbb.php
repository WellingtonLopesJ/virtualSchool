<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>


    <div class="container" >
        <h1 class="title">
            Users list
        </h1>


        <table class="table table-hover">
            <?php echo $__env->make('layouts.showResponse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Criar user</a>
            <tr>
                <th>Name</th>
                <th>Tenant</th>
                <th>Email</th>
                <th width="150px">Ações</th>
            </tr>

            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->tenant()->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <a href="<?php echo e(route('users.show',$user->name)); ?>" class="permission btn btn-primary">
                            <i class="fa fa-lock"></i>
                        </a>

                        <form action="<?php echo e(route('users.destroy', $user->name)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="90">
                        <p>Nenhum Resultado!</p>
                    </td>
                </tr>
            <?php endif; ?>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/panel/users/index.blade.php ENDPATH**/ ?>