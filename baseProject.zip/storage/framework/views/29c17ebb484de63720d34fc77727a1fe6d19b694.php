<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php echo $__env->make('layouts.showResponse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('users.store_role')); ?>" method="POST">

            <?php echo csrf_field(); ?>

            <header><h3>Adicionar role para <?php echo e($user->name); ?></h3></header>

            <div class="form-group">
                <label for="permissions">Roles</label>

                <input type="hidden" name="user_name" value="<?php echo e($user->name); ?>">

                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="<?php echo e($role->id); ?>" value="<?php echo e($role->id); ?>" name="roles[]">
                    <label class="form-check-label" for="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>

            </div>

            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/admin/users/giveRole.blade.php ENDPATH**/ ?>