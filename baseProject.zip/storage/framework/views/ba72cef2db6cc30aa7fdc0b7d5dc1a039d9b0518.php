<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php echo $__env->make('layouts.showResponse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('users.store')); ?>" method="POST">

            <?php echo csrf_field(); ?>
            <header><h3>Criar novo user</h3></header>
            <div class="form-group">
                <label for="name">Nome:</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Nome">
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email">
            </div>

            <div class="form-group">
                <label for="password">Senha:</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Nome">
            </div>

            <div class="form-group">
                <label for="permissions">Roles</label>


                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="<?php echo e($role->id); ?>" value="<?php echo e($role->id); ?>" name="roles[]">
                        <label class="form-check-label" for="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>

            </div>

            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_new\htdocs\baseProject\resources\views/admin/users/create.blade.php ENDPATH**/ ?>