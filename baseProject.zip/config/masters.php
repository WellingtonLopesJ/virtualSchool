<?php

return[

    //Id's of master tenants
        'ids' => [1,5]

];
